from flask import Flask, render_template, request, redirect, url_for, g
import sqlite3
from datetime import datetime

app = Flask(__name__)
DATABASE = 'database.db'
VALOR_PASSAGEM = 5.00

def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

def init_db():
    with app.app_context():
        db = get_db()
        db.execute('''
            CREATE TABLE IF NOT EXISTS cartoes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL,
                saldo REAL NOT NULL,
                status TEXT NOT NULL,
                data_criacao TEXT NOT NULL
            )
        ''')
        db.execute('''
            CREATE TABLE IF NOT EXISTS historico (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                cartao_id INTEGER,
                data_hora TEXT NOT NULL,
                status TEXT NOT NULL,
                motivo TEXT,
                valor_cobrado REAL,
                FOREIGN KEY (cartao_id) REFERENCES cartoes (id)
            )
        ''')
        db.commit()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/criar-cartao', methods=['GET', 'POST'])
def criar_cartao():
    if request.method == 'POST':
        nome = request.form['nome']
        saldo = float(request.form['saldo'])
        db = get_db()
        cursor = db.execute(
            'INSERT INTO cartoes (nome, saldo, status, data_criacao) VALUES (?,?,?,?)',
            (nome, saldo, 'Ativo', datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
        )
        db.commit()
        cartao_id = cursor.lastrowid
        return redirect(url_for('visualizar_cartao', cartao_id=cartao_id))
    return render_template('criar_cartao.html')

@app.route('/cartao/<int:cartao_id>')
def visualizar_cartao(cartao_id):
    db = get_db()
    cartao = db.execute('SELECT * FROM cartoes WHERE id =?', (cartao_id,)).fetchone()
    return render_template('visualizar_cartao.html', cartao=cartao)

@app.route('/catraca')
def catraca():
    return render_template('catraca.html')

@app.route('/validar-catraca', methods=['POST'])
def validar_catraca():
    cartao_id = request.form['cartao_id']
    db = get_db()
    cartao = db.execute('SELECT * FROM cartoes WHERE id =?', (cartao_id,)).fetchone()

    status = 'negado'
    motivo = 'Cartão não encontrado'
    valor_cobrado = 0.0

    if cartao:
        if cartao['status']!= 'Ativo':
            motivo = 'Cartão bloqueado'
        elif cartao['saldo'] < VALOR_PASSAGEM:
            motivo = 'Saldo insuficiente'
        else:
            novo_saldo = cartao['saldo'] - VALOR_PASSAGEM
            db.execute('UPDATE cartoes SET saldo =? WHERE id =?', (novo_saldo, cartao_id))
            status = 'aprovado'
            motivo = 'Entrada liberada'
            valor_cobrado = VALOR_PASSAGEM

    db.execute(
        'INSERT INTO historico (cartao_id, data_hora, status, motivo, valor_cobrado) VALUES (?,?,?,?,?)',
        (cartao_id, datetime.now().strftime('%Y-%m-%d %H:%M:%S'), status, motivo, valor_cobrado)
    )
    db.commit()

    return render_template('resultado.html', status=status, motivo=motivo, cartao=cartao)

@app.route('/historico')
def historico():
    db = get_db()
    registros = db.execute('SELECT * FROM historico ORDER BY data_hora DESC').fetchall()
    return render_template('historico.html', registros=registros)

if __name__ == '__main__':
    init_db()
    app.run(host='0.0.0.0', port=5000, debug=True)