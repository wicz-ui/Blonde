# Sistema de Catraca Virtual para Ônibus

sistema-catraca/
├── app.py
├── templates/
│ ├── base.html
│ ├── index.html
│ ├── criar_cartao.html
│ ├── visualizar_cartao.html
│ ├── catraca.html
│ ├── resultado.html
│ └── historico.html
└── static/
    └── style.css

Pra rodar:
pip install flask
python app.py
Abre a porta 5000 como pública no CodespacesEsse código já cobre todo o MVP do seu PRD: criar cartão, validar na catraca, salvar no SQLite e histórico.Quer que eu já faça os outros arquivos HTML também, ou o style.css responsivo pra resolver o Risco 3 do mobile?

## Objetivo
Simular o funcionamento de uma catraca de ônibus usando Python, Flask, HTML, CSS e SQLite. 
Demonstração acadêmica rodando no GitHub Codespaces com acesso por 2 celulares.

## Como rodar
1. `pip install flask`
2. `python app.py`
3. Tornar a porta 5000 pública no Codespaces
4. Acessar o link gerado nos celulares

## MVP - Funcionalidades
- Criar cartão virtual
- Visualizar cartão com ID
- Validar entrada na catraca
- Aprovar/negar entrada + descontar R$ 5,00
- Registrar histórico no SQLite

## Divisão de tarefas
**Pessoa 1 - Back-end**: `app.py`, rotas Flask, validação
**Pessoa 2 - Banco**: SQLite, tabelas `cartoes` e `passagens` 
**Pessoa 3 - Front-end**: HTML/CSS responsivo
**Pessoa 4 - Testes**: Codespaces, demo em 2 celulares, roteiro

## Roteiro de demonstração
1. Abrir sistema no PC via Codespaces
2. Celular 1: Criar cartão → anotar ID
3. Celular 2: Acessar catraca → digitar ID → validar
4. Mostrar "Entrada Aprovada"
5. Consultar cartão: saldo descontado
6. Ver histórico de passagens
7. Testar ID inválido: "Entrada Negada"